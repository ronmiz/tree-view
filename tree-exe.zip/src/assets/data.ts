// items: any = [
//     {
//       name: "Pictures",
//       code: "PCTRS",
//       children: [
//         {
//           name: "Vacation",
//           code: "VAC",
//           children: [
//             {
//               name: "Image 1",
//               code: "IMG_111",items
//               children: null,
//             },
//             {
//               name: "Image 2",
//               code: "IMG_212",
//               children: null,
//             },
//           ],
//         },
//         {
//           name: "Graduation",
//           code: "GRAD",
//           children: [
//             {
//               name: "Image 3",
//               code: "grad_111",
//               children: null,
//             },
//             {
//               name: "Image 4",
//               code: "grad_212",
//               children: null,
//             },
//           ],
//         },
//       ],
//     },
//     {
//       name: "Videos",
//       code: "VDS",
//       children: [
//         {
//           name: "Video 1",
//           code: "vid1",
//           children: [],
//         },
//         {
//           name: "Video 2",
//           code: "vid2",
//           children: [],
//         },
//       ],
//     },
//   ];
